gometalinter is a tool to normalise the output of Go linters.
See https://github.com/alecthomas/gometalinter for more information.

This is a binary distribution of gometalinter v2.0.2.

All binaries must be installed in the PATH for gometalinter to operate correctly.
